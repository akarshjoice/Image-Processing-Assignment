import math
import cv2

image = cv2.imread('image2.png', 0)
image = image[0:30, 0:30]
N = image.shape[0]
n = N
c_final = []


pi = math.pi

for u in range(n):
    c = []
    for v in range(n):
        sum = 0
        for x in range(n):
            for y in range(n):
                arg1 = (pi * u * ((2 * x) + 1)) / (2 * n)
                arg2 = (pi * v * ((2 * y) + 1)) / (2 * n)
                ele = math.cos(arg1)*math.cos(arg2)*image[x][y]
                #print(f[x][y])
                sum = sum+ele
        if u == 0 and v==0:

            alpha_u = 1/math.sqrt(n)
            alpha_v = 1/math.sqrt(n)
        elif u == 0 and v>0:
            alpha_u = 1 / math.sqrt(n)
            alpha_v =  math.sqrt(2/n)
        elif u>0 and v==0:
            alpha_u = math.sqrt(2/n)
            alpha_v = 1 / math.sqrt(n)
        else:
            alpha_u = math.sqrt(2/n)
            alpha_v = math.sqrt(2/n)
        c.append(sum*alpha_u*alpha_v)
    c_final.append(c)
print(c_final)
for i in range(N):
    for j in range(N):
        image[i][j] = c_final[i][j]

cv2.imshow('image', image)
cv2.imwrite("q13d.png",image)
cv2.waitKey(0)
cv2.destroyAllWindows()