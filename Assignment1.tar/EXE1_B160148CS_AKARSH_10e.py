import math
import cv2


image = cv2.imread('q10d.png',0)
image=image[0:10,0:10]

image1 = cv2.imread('image2.png',0)
image1=image1[0:10,0:10]

m=image.shape[0]
n=image.shape[1]
for i in range(m):
    for j in range(n):
        image[i][j]=image[i][j]*math.pow(-1,(i+j))

cv2.imshow("image",image)
cv2.imwrite("q10e.png",image)
cv2.waitKey(0)
cv2.destroyAllWindows()
