import numpy as np
import cv2
from matplotlib import pyplot as plt
# 2 Dimension Fourier Transform:
def FT_2D(X):
    m, n = X.shape
    return np.array([ [ sum([ sum([ X[i,j]*np.exp(-1j*2*np.pi*(k_m*i/m + k_n*j/n)) for i in range(m) ]) for j in range(n) ]) for k_n in range(n) ] for k_m in range(m) ])
# 2 Dimension Inverse Fourier Transform:
def IFT_2D(X):
    m, n = X.shape
    return np.array([ [ sum([ sum([ X[i,j]*np.exp(1j*2*np.pi*(k_m*i/m + k_n*j/n)) for i in range(m) ]) for j in range(n) ]) for k_n in range(n) ] for k_m in range(m) ])

q11img=cv2.imread('image.png',0)
q11img=cv2.resize(q11img  , (75 , 75))
q11img_DFT=FT_2D(q11img)
q11img_padded=np.pad(q11img, pad_width=1, mode='constant', constant_values=0)
q11img_padded_DFT=FT_2D(q11img_padded)
q11img_IDFT=IFT_2D(q11img_DFT)
q11img_padded_IDFT=IFT_2D(q11img_padded_DFT)
plt.figure(figsize=(10,10))
plt.subplot(231),plt.imshow(q11img, cmap = 'gray')
plt.title('Input Image'), plt.xticks([]), plt.yticks([])
plt.subplot(232),plt.imshow(np.log(np.abs(q11img_DFT)), cmap = 'gray')
plt.title('Fourier Transform'), plt.xticks([]), plt.yticks([])
plt.subplot(233),plt.imshow(np.abs(q11img_IDFT), cmap = 'gray')
plt.title('Input Image Reconstructed'), plt.xticks([]), plt.yticks([])
plt.subplot(234),plt.imshow(q11img_padded, cmap = 'gray')
plt.title('Padded Image'), plt.xticks([]), plt.yticks([])
plt.subplot(235),plt.imshow(np.log(np.abs(q11img_padded_DFT)), cmap = 'gray')
plt.title('Padded Image FT'), plt.xticks([]), plt.yticks([])
plt.subplot(236),plt.imshow(np.abs(q11img_padded_IDFT), cmap = 'gray')
plt.title('Padded Image Reconstructed'), plt.xticks([]), plt.yticks([])
plt.savefig('q11.png')
plt.show()
