import math
import cv2


image = cv2.imread('image2.png',0)
image=image[0:10,0:10]
image1 = cv2.imread('image2.png',0)
image1=image1[0:10,0:10]


m=image.shape[0]
n=image.shape[1]
for i in range(m):
    for j in range(n):
        image[i][j]=image[i][j]*math.pow(-1,(i+j))


cv2.imshow("image",image)
cv2.waitKey(0)
cv2.destroyAllWindows()
m=image.shape[0]
n=image.shape[1]
c_final = []
pi = math.pi





for u in range(m):
    c = []
    for v in range(n):
        sum = 0
        for x in range(m):
            for y in range(n):
                ele = (complex(math.cos(2*pi*u*x/m),-1*math.sin(2*pi*u*x/m))) * (complex(math.cos(2*pi*v*y/n),-1*math.sin(2*pi*v*y/n))) * image[x][y]
                sum = sum+ele

        c.append(int(sum.real/(n*m)))
        image1[x][y] = int(sum.real/(n*m))
    c_final.append(c)
for i in range(m):
    for j in range(n):
        image1[i][j] = c_final[i][j]

#for i in range(n):
#    for j in range(m):
 #           print(c_final[i][j],end=" ")
 #   print()
#print(c_final)
#cv2.dft(image,image,1,cv2.32_U)
cv2.imshow("image",image)
cv2.waitKey(0)
cv2.destroyAllWindows()

c_final = []

for u in range(m):
    c = []
    for v in range(n):
        sum = 0
        for x in range(m):
            for y in range(n):
                ele = (complex(math.cos(2*pi*u*x/m),1*math.sin(2*pi*u*x/m))) * (complex(math.cos(2*pi*v*y/n),1*math.sin(2*pi*v*y/n))) * image1[x][y]
                sum = sum+ele

        c.append(int(sum))
        image1[x][y] = int(sum.real)
    c_final.append(c)
for i in range(m):
    for j in range(n):
        image1[i][j] = c_final[i][j]

cv2.imshow("image",image1)
cv2.imwrite("q10d.png",image1)
cv2.waitKey(0)
cv2.destroyAllWindows()
