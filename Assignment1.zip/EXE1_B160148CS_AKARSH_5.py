import cv2
import math

img = cv2.imread('image.png',0)
img=img[0:64,0:64]


for i in range(0,64):
    for j in range(0,64):
         p=math.fabs(math.cos(math.sqrt(i*i + j*j)))

         if p>=0 and p<0.25:
                p=0
         elif p>=0.25 and p<0.5:
                p=0.25
         elif p>=0.5 and p<0.75:
                p=0.5
         elif p>=0.75 and p<1:
                p=0.75
         else:
             p=1

         img[i, j] = p
cv2.imshow('image', img)
cv2.imwrite('q5.png',img)
cv2.waitKey(0)
cv2.destroyAllWindows()