import numpy as np
import matplotlib.pyplot as plt
import cv2




img1 = cv2.imread('q9a.png',0)

img2 = cv2.imread('q9b.png',0)
# create subplot and append to ax

img3 = cv2.imread('q9c.png',0)
# create subplot and append to ax

img4 = cv2.imread('q9d.png',0)
# create subplot and append to ax


img5 = cv2.imread('q9e.png',0)


img6 = cv2.imread('q9f.png',0)
# create subplot and append to ax

# do extra plots on selected axes/subplots
# note: index starts with 0
# ax[2].plot(xs, 3*ys)
# ax[19].plot(ys**2, xs)

fig, axs = plt.subplots(3, 2, figsize=(10, 10), constrained_layout=True)
axs[0][0].imshow(img1)
axs[0][0].set_title("9a")
axs[0][1].imshow(img2)
axs[0][1].set_title("9b")
axs[1][0].imshow(img3)
axs[1][0].set_title("9c")
axs[1][1].imshow(img4)
axs[1][1].set_title("9d")
axs[2][0].imshow(img5)
axs[2][0].set_title("9e")
axs[2][1].imshow(img6)
axs[2][1].set_title("9f")

plt.show()
plt.savefig('q9g.png')