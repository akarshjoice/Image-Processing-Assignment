import cv2

img = cv2.imread('image.png',0)
img1 = cv2.imread('image2.png',0)


img=img[0:300,0:300]
img1=img1[0:300,0:300]


cv2.imshow('image',img1)
cv2.waitKey(0)


image= ~img1


cv2.imshow('image',image)
cv2.imwrite('q8c.png',image)
cv2.waitKey(0)
cv2.destroyAllWindows()