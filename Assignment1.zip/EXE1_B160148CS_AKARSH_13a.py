import math
import cv2

def bin_fun(u,x,v,y,n):

    u_bin = int("{0:b}".format(u))
    x_bin = int("{0:b}".format(x))
    u_bin_arr = []
    x_bin_arr = []

    v_bin = int("{0:b}".format(v))
    y_bin = int("{0:b}".format(y))
    v_bin_arr = []
    y_bin_arr = []

    while u_bin>0:
        u_bin_arr.append(int(u_bin%10))
        u_bin = int(u_bin/10)
    while len(u_bin_arr)<n:
        u_bin_arr.append(0)
    while x_bin > 0:
        x_bin_arr.append(int(x_bin % 10))
        x_bin = int(x_bin / 10)
    while len(x_bin_arr)<n:
        x_bin_arr.append(0)

    while v_bin > 0:
        v_bin_arr.append(int(v_bin % 10))
        v_bin = int(v_bin / 10)
    while len(v_bin_arr) < n:
        v_bin_arr.append(0)
    while y_bin > 0:
        y_bin_arr.append(int(y_bin % 10))
        y_bin = int(y_bin / 10)
    while len(y_bin_arr) < n:
        y_bin_arr.append(0)


    # u_bin_arr.reverse()
    # x_bin_arr.reverse()
    # v_bin_arr.reverse()
    # y_bin_arr.reverse()

    sum = 0
    prod = 1
    for i in range(n):
        ele = (u_bin_arr[n-1-i]*x_bin_arr[i]) + (v_bin_arr[n-1-i]*y_bin_arr[i])
        prod = prod * math.pow(-1, ele)
    return prod

if __name__ == "__main__":
    image=cv2.imread('image2.png', 0)
    image=image[0:8,0:8]
    N=image.shape[0]
    n = int(math.log(N, 2))
    c_final = []
    for u in range(N):
        c = []
        for v in range(N):
            sum = 0
            for x in range(N):
                for y in range(N):
                    ele = bin_fun(u,x,v,y,n) * image[x][y]
                    # print(bin_fun(u,x,v,y,n))
                    sum = sum+ele
            # if v==1:
            #     print(sum)

            c.append(sum/N)
        c_final.append(c)
    print(c_final)
for i in range(N):
    for j in range(N):
        image[i][j]=c_final[i][j]

cv2.imshow('image',image)
cv2.imwrite("q13a.png",image)
cv2.waitKey(0)
cv2.destroyAllWindows()

