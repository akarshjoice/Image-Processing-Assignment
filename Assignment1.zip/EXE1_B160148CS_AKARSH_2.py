import cv2

sum=0
img = cv2.imread('image.png',0)



for i in range(0,img.shape[0]):
    for j in range(0,img.shape[1]):
         sum+=img[i,j]


mean=sum/img.size
print(mean)

for i in range(0,img.shape[0]):
    for j in range(0,img.shape[1]):
         if(img[i][j]>mean):
                   img[i][j]=1
         else:
                    img[i][j]=0

cv2.imshow('image',img)
cv2.imwrite('q2.png',img)
cv2.waitKey(0)
cv2.destroyAllWindows()