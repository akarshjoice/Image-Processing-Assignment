import math
import cv2


image = cv2.imread('image2.png',0)
image=image[0:30,0:30]


f= cv2.imread('image2.png',0)
f=f[0:30,0:30]
m=image.shape[0]
n=image.shape[1]
c_final = []
pi = math.pi





for u in range(m):
    c = []
    for v in range(n):
        sum = 0
        for x in range(m):
            for y in range(n):
                ele = (complex(math.cos(2*pi*u*x/m),-1*math.sin(2*pi*u*x/m))) * (complex(math.cos(2*pi*v*y/n),-1*math.sin(2*pi*v*y/n))) * image[x][y]
                sum = sum+ele

        c.append(int(sum/(n*m)))
        f[x][y] = int(sum.real/(n*m))
    c_final.append(c)
for i in range(m):
    for j in range(n):
        f[i][j] = c_final[i][j]
#for i in range(n):
#     for j in range(m):
#            print(c_final[i][j],end=" ")
#     print()
#print(c_final)
#cv2.dft(image,image,1,cv2.32_U)

cv2.imshow("image",f)
cv2.imwrite('q9a.png',f)
cv2.waitKey(0)
cv2.destroyAllWindows()

